import csv
import random
import pygame
import os
from pygame.transform import scale
from pygame import mixer
import button

pygame.init()
mixer.init()
MAX_LEVELS = 3
SCREEN_WIDTH = 1080
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)
start_intro = False
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('OZ WIZARD')
BLACK = (0, 0, 0)
PINK = (235, 65, 54)
# Set framerate
clock = pygame.time.Clock()
FPS = 100
SCROLL_THRESH = 200
screen_scroll = 0
bg_scroll = 0
# Define game variables
GRAVITY = 0.75
ROWS = 16
COLS = 150
TILE_SIZE = SCREEN_HEIGHT // ROWS
TILE_TYPES = 21
level = 1
# Define player action variables
moving_left = False
moving_right = False
shoot = False
throw_grenade = False
grenade_thrown = False  # Track if a grenade is already thrown
start_game = False
# load initial images
start_img = pygame.image.load('start_btn.png').convert_alpha()
exit_img = pygame.image.load('exit_btn.png').convert_alpha()
restart_img = pygame.image.load('restart_btn.png').convert_alpha()
save_img = pygame.image.load('save_btn.png').convert_alpha()

# load music
# load music
pygame.mixer.music.load('Audio/background_music.mp3')
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1, 0.0, 5000)

# load sound effects
jump_fx = pygame.mixer.Sound('Audio/jump.wav')
jump_fx.set_volume(0.5)
shot_fx = pygame.mixer.Sound('Audio/shot.wav')
shot_fx.set_volume(0.5)

# load image


pine1_img = pygame.image.load('Background/pine1.png').convert_alpha()
pine2_img = pygame.image.load('Background/pine2.png').convert_alpha()
mountain_img = pygame.image.load('Background/mountain.png').convert_alpha()
sky_img = pygame.image.load('Background/sky_cloud.png').convert_alpha()

# store tiles
img_list = []
for x in range(TILE_TYPES):
    img = pygame.image.load(f'Tile/{x}.png')
    img = pygame.transform.scale(img, (TILE_SIZE, TILE_SIZE))
    img_list.append(img)
# Load fireballs and grenades
fireball_img = pygame.image.load('player/fireball.png').convert_alpha()
goofball_img = pygame.image.load('grenade.png').convert_alpha()

# Define colors
BG = pygame.image.load('wiz.jpg')
RED = (255, 0, 0)
WHITE = (255, 255, 255)
font = pygame.font.SysFont('Futura', 30)


def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

from datetime import datetime  # Add this import at the top of your code

def save_score(score):
    # Get the current date and time
    now = datetime.now()
    date_string = now.strftime("%Y-%m-%d %H:%M:%S")  # Format: 'YYYY-MM-DD HH:MM:SS'

    # Open the CSV file in append mode, create if it doesn't exist
    with open('high_scores.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([score, date_string])

    print("Score saved successfully!")  # Optional: Console feedback

def draw_bg():

    width = sky_img.get_width()
    for a in range(5):
        screen.blit(sky_img, ((a * width) - bg_scroll * 0.5, 0))
        screen.blit(mountain_img, ((a * width) - bg_scroll * 0.6, SCREEN_HEIGHT - mountain_img.get_height() - 350))
        screen.blit(pine1_img, ((a * width) - bg_scroll * 0.7, SCREEN_HEIGHT - pine1_img.get_height() - 200))
        screen.blit(pine2_img, ((a * width) - bg_scroll * 0.8, SCREEN_HEIGHT - pine2_img.get_height()))


def reset_level():
    enemy_group.empty()
    fireball_group.empty()
    goofball_group.empty()
    explosion_group.empty()
    item_box_group.empty()
    decoration_group.empty()
    coin_group.empty()
    water_group.empty()
    exit_group.empty()

    # create empty tile list
    data = []
    for row in range(ROWS):
        r = [-1] * COLS
        data.append(r)
    return data


# HealthBar class
class HealthBar:
    def __init__(self, x, y, width=100, height=20, border_color=(0, 0, 0), fill_color=(255, 0, 0)):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.border_color = border_color
        self.fill_color = fill_color

    def draw(self, current_health, max_health):
        # Calculate the ratio of current health to max health
        ratio = current_health / max_health
        # Draw the background (border)
        pygame.draw.rect(screen, self.border_color, (self.x, self.y, self.width, self.height))
        # Draw the health bar (red fill)
        pygame.draw.rect(screen, self.fill_color, (self.x, self.y, int(self.width * ratio), self.height))


class Score:
    def __init__(self):
        self.value = 0  # Initialize score to 0

    def increment(self, points):
        self.value += points  # Increment score by the given points

    def draw(self):
        draw_text(f'Score: {self.value}', font, WHITE, 10, 10)



# Wizard class
# noinspection PyTypeChecker
class Wizard(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, scale, speed, mana, goofball):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.char_type = char_type
        self.speed = speed
        self.direction = 1
        self.mana = mana
        self.start_mana = mana
        self.vel_y = 0
        self.shoot_cooldown = 0
        self.jump = False
        self.health = 100
        self.max_health = self.health
        self.in_air = True
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()
        self.goofball = goofball
        self.score = Score()

        # Create health bar for the wizard
        self.health_bar = HealthBar(x, y - 20, width=50, height=10)

        # Define the animation types based on the character type
        if char_type == 'player':
            animation_types = ['Idle', 'Run', 'Jump', 'Death']
            self.health_bar = HealthBar(x, y - 20, width=50, height=10, border_color=(0, 0, 0),
                                        fill_color=(0, 255, 0))  # Green for player
        elif char_type == 'enemy':
            animation_types = ['Idle', 'Run', 'Kill']
            self.health_bar = HealthBar(x, y - 20, width=50, height=10, border_color=(0, 0, 0),
                                        fill_color=(255, 0, 0))  # Red for enemy
        elif char_type == 'minion':
            animation_types = ['Idle', 'Walk', 'Attack', 'Death']
            self.health_bar = HealthBar(x, y - 20, width=50, height=10, border_color=(0, 0, 0),
                                        fill_color=(255, 0, 0))  # Red for enemy

        # Load animations for the character
        for animation in animation_types:
            temp_list = []
            num_of_frames = len(os.listdir(f'{self.char_type}/{animation}'))
            for i in range(num_of_frames):
                img = pygame.image.load(f'{self.char_type}/{animation}/{i}.png').convert_alpha()
                img = pygame.transform.scale(img, (int(40 * scale), int(58 * scale)))
                temp_list.append(img)
            self.animation_list.append(temp_list)

        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.rect.bottom = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()

    def update(self):
        self.update_animation()
        self.check_alive()

        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1

        if not self.alive and self.char_type == 'player':
            if self.action == 3:
                if self.frame_index >= len(self.animation_list[3]) - 1:
                    self.kill()

    def move(self, moving_left, moving_right):
        # reset movement variables
        screen_scroll = 0
        dx = 0
        dy = 0

        if moving_left:
            dx = -self.speed
            self.flip = True
            self.direction = -1
        if moving_right:
            dx = self.speed
            self.flip = False
            self.direction = 1

        # jump
        if self.jump == True and self.in_air == False:
            self.vel_y = -16
            self.jump = False
            self.in_air = True

        # apply gravity
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y = 10  # Limit the velocity for smooth movement
        dy += self.vel_y

        # check for collision with obstacles
        for tile in world.obstacle_list:
            # check collision in the x direction
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
            # check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                # check if below the ground, i.e. jumping
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                # check if above the ground, i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    self.in_air = False
                    dy = tile[1].top - self.rect.bottom
        # water
        if pygame.sprite.spritecollide(self, water_group, False):
            self.health = 0
        # check if going off the edges of the screen
        if self.char_type == 'player':
            if self.rect.left + dx < 0 or self.rect.right + dx > SCREEN_WIDTH:
                dx = 0
        # check if fallen off the map
        if self.rect.bottom > SCREEN_HEIGHT:
            self.health = 0

        # check for collision with exit
        level_complete = False
        if pygame.sprite.spritecollide(self, exit_group, False):
            level_complete = True

        # update rectangle position
        self.rect.x += dx
        self.rect.y += dy

        # update scroll based on player position
        if self.char_type == 'player':
            if (self.rect.right > SCREEN_WIDTH - SCROLL_THRESH and bg_scroll < (
                    world.level_length * TILE_SIZE - SCREEN_WIDTH)) \
                    or (self.rect.left < SCROLL_THRESH and bg_scroll > abs(dx)):
                self.rect.x -= dx
                screen_scroll = -dx

        return screen_scroll, level_complete

    def shoot(self):
        if self.shoot_cooldown == 0 and self.mana > 0:
            self.shoot_cooldown = 20
            fireball = Fireball(self.rect.centerx + (0.6 * self.rect.size[0] * self.direction),
                                self.rect.centery + 19, self.direction)
            fireball_group.add(fireball)
            self.mana -= 1

    def update_animation(self):
        ANIMATION_COOLDOWN = 100
        self.image = self.animation_list[self.action][self.frame_index]

        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1

        if self.frame_index >= len(self.animation_list[self.action]):
            if self.action == 3 and self.char_type == 'player':
                self.frame_index = len(self.animation_list[self.action]) - 1
            else:
                self.frame_index = 0

    def update_action(self, new_action):
        if new_action != self.action:
            self.action = new_action
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            if self.char_type == 'player':
                if self.alive:
                    self.update_action(3)
                    self.alive = False
            elif self.char_type == 'enemy':
                self.kill()

    def draw(self):
        # Update health bar position relative to the player's position
        self.health_bar.x = self.rect.x + (self.width - self.health_bar.width) // 2  # Center it above the player
        self.health_bar.y = self.rect.y - self.health_bar.height - 5  # Adjust to be just above the player

        # Draw the player sprite
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)

        # Draw the health bar
        self.health_bar.draw(self.health, self.max_health)


class EnemyAI(Wizard):
    def __init__(self, char_type, x, y, scale, speed, patrol_range, detection_range=350):
        super().__init__(char_type, x, y, scale, speed, mana=0, goofball=0)
        self.patrol_range = patrol_range
        self.patrol_direction = 0  # 1 means moving right, -1 means moving left
        self.patrol_start = x
        self.patrol_end = x + patrol_range + (x * patrol_range)
        self.detection_range = detection_range  # Range to detect player
        self.melee_range = 40  # Range for melee attack
        self.attack_cooldown = 0
        self.health = 500
        self.dialogues = [
            "You can't escape my gaze!",
            "Feel the wrath of Medusa!",
            "Turn to stone, mortal!",
            "You dare to challenge me?"
        ]
        self.dialogue_text = ""  # To store the active dialogue
        self.dialogue_timer = 0

    def update_animation(self):
        ANIMATION_COOLDOWN = 100
        self.image = self.animation_list[self.action][self.frame_index]

        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1

        # If the action is the "Kill" animation (index 2), ensure it plays out fully before resetting
        if self.action == 2:  # Assuming 'Kill' is the action at index 2
            if self.frame_index >= len(self.animation_list[self.action]):
                self.frame_index = len(
                    self.animation_list[self.action]) - 1  # Stop at the last frame for Kill animation
        else:
            if self.frame_index >= len(self.animation_list[self.action]):
                self.frame_index = 0

    def say_random_dialogue(self):
        # Only say a new dialogue if the timer is not active
        if random.random() < 0.01 and self.dialogue_timer <= 0:  # Adjust frequency of dialogues
            self.dialogue_text = random.choice(self.dialogues)
            self.dialogue_timer = 3000  # Display for 3 seconds (3000 milliseconds)

    def melee_attack(self, player):
        # Check horizontal and vertical distance between enemy and player
        horizontal_distance = abs(self.rect.centerx - player.rect.centerx)
        vertical_distance = abs(self.rect.centery - player.rect.centery)

        # Define a horizontal and vertical range for the melee attack
        if horizontal_distance <= self.melee_range and vertical_distance <= player.height * 0.5:
            # Perform attack only if cooldown is zero
            if self.attack_cooldown == 0:
                player.health -= 40  # Reduce player's health by 20

                self.attack_cooldown = 30  # Set cooldown to prevent multiple attacks at once
                self.update_action(2)  # Change to attack animation (e.g., 'Kill' action)

    def patrol(self):
        # Check if the enemy has reached the patrol boundaries
        if self.rect.x <= self.patrol_start:
            self.patrol_direction = 1  # Move right
        elif self.rect.x >= self.patrol_end:
            self.patrol_direction = -1  # Move left

        # Move the enemy based on the patrol direction
        moving_left = self.patrol_direction == -1
        moving_right = self.patrol_direction == 1

        # Ensure collision detection does not reset the patrol direction unexpectedly
        dx = (self.patrol_direction * self.speed)
        dy = self.vel_y

        # Apply gravity and update position
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y = 10  # Limit the falling speed
        dy += self.vel_y

        # Handle patrol movement
        self.move(moving_left, moving_right)

    def move(self, moving_left, moving_right, player_detected=False, player=None):
        if self.alive:
            dx = 0
            dy = 0

            # Apply gravity so the enemy can fall
            self.vel_y += GRAVITY
            if self.vel_y > 10:
                self.vel_y = 10  # Limit the falling speed
            dy += self.vel_y

            # If the player is detected, chase the player
            if player_detected and player:
                if player.rect.centerx > self.rect.centerx:
                    dx = self.speed  # Move right towards the player
                    self.direction = 1
                    self.flip = False
                elif player.rect.centerx < self.rect.centerx:
                    dx = -self.speed  # Move left towards the player
                    self.direction = -1
                    self.flip = True
                self.update_action(1)  # Run animation when chasing

            # If no player is detected, continue patrolling
            elif not player_detected:
                if moving_left:
                    dx = -self.speed
                    self.flip = True
                    self.direction = -1
                    self.update_action(1)  # Run animation
                elif moving_right:
                    dx = self.speed
                    self.flip = False
                    self.direction = 1
                    self.update_action(1)  # Run animation
                else:
                    self.update_action(0)  # Idle animation

            # Collision handling with tiles
            for tile in world.obstacle_list:
                # Check collision in the x direction (horizontal movement)
                if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                    dx = 0  # Stop movement if hitting a wall

                # Check collision in the y direction (vertical movement)
                if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                    # If falling (moving down)
                    if self.vel_y >= 0:
                        self.vel_y = 0
                        self.in_air = False  # The enemy is grounded
                        dy = tile[1].top - self.rect.bottom  # Place the enemy on top of the tile

            # Update the enemy's position
            self.rect.x += dx
            self.rect.y += dy

            # If there's no ground below, mark the enemy as falling
            is_on_ground = any(tile[1].colliderect(self.rect.x, self.rect.y + 1, self.width, self.height) for tile in
                               world.obstacle_list)
            if not is_on_ground:
                self.in_air = True

            # Handle screen scrolling
            self.rect.x += screen_scroll

    def update(self, player):
        self.check_alive()
        if self.alive:
            player_detected = self.detect_player(player)

            if player_detected:
                self.say_random_dialogue()
                self.melee_attack(player)  # Call melee attack if player is within range

            # Only switch actions if the attack cooldown is zero, so the Kill animation can fully play
            if self.attack_cooldown == 0:
                # Move the enemy, either chasing the player or patrolling
                self.move(moving_left=self.patrol_direction == -1,
                          moving_right=self.patrol_direction == 1,
                          player_detected=player_detected,
                          player=player)
            else:
                # Decrease attack cooldown if still active
                self.attack_cooldown -= 1

            self.update_animation()

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.alive = False  # Mark as not alive
            player.score.increment(10)  # Increment the player's score
            self.kill()

    def detect_player(self, player):
        # Check if the player is within the detection range (distance between enemy and player)
        distance_to_player = abs(self.rect.centerx - player.rect.centerx)
        if distance_to_player <= self.detection_range:
            # If within detection range, start interaction (dialogue or melee)
            return True
        return False

    def draw(self):
        if self.alive:
            super().draw()  # Only draw if the enemy is alive

            # Draw the dialogue if the timer is active
            if self.dialogue_timer > 0:
                draw_text(self.dialogue_text, font, RED, self.rect.x, self.rect.y - 30)

            # Update the health bar position relative to the enemy's position
            self.health_bar.x = self.rect.x + (self.width - self.health_bar.width) // 2
            self.health_bar.y = self.rect.y - self.health_bar.height - 5
            self.health_bar.draw(self.health, self.max_health)




class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.animation_list = []
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()

        # Load all frames from the Coin directory
        num_of_frames = len(os.listdir('Coin'))
        for i in range(num_of_frames):
            img = pygame.image.load(f'Coin/{i}.png').convert_alpha()
            img = pygame.transform.scale(img, (30, 30))
            self.animation_list.append(img)

        # Set the first image for the coin
        self.image = self.animation_list[self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update_animation(self):
        ANIMATION_COOLDOWN = 100  # Time between frame updates (in milliseconds)

        # Update animation if enough time has passed
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1

            # Loop the animation
            if self.frame_index >= len(self.animation_list):
                self.frame_index = 0

            # Update the current image
            self.image = self.animation_list[self.frame_index]

    def update(self):
        # Update the animation
        self.update_animation()

        # Move the coin if the screen scrolls
        self.rect.x += screen_scroll

        # Check if the player collects the coin
        if pygame.sprite.collide_rect(self, player):
            player.score.increment(5)  # Increment the player's score by 5
            self.kill()  # Remove the coin from the game



# Fireball class (remains unchanged)
class Fireball(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10  # Horizontal speed
        self.image = fireball_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y - 10)
        self.direction = direction
        self.shooter = player  # Store the shooter to avoid self-hit

    def update(self):
        # Move the fireball only horizontally
        self.rect.x += (self.direction * self.speed)

        # Remove the fireball if it goes off the screen
        if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH:
            self.kill()
        # collision level
        for tile in world.obstacle_list:
            if tile[1].colliderect(self.rect):
                self.kill()

        # Check if the fireball collides with any enemies, but not the shooter
        if self.shooter != player and pygame.sprite.spritecollide(player, fireball_group, False):
            if player.alive:
                player.health -= 5
                self.kill()

        # Check if fireball hits enemies
        for enemy in enemy_group:
            if pygame.sprite.spritecollide(enemy, fireball_group, False):
                if enemy.alive:
                    enemy.health -= 25
                    self.kill()


class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, scale):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for num in range(1, 6):
            img = pygame.image.load(f'explosion/exp{num}.png').convert_alpha()
            img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
            self.images.append(img)
        self.speed = 10
        self.frame_index = 0
        self.image = self.images[self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.counter = 0

    def update(self):
        self.rect.x += screen_scroll
        EXPLOSION_SPEED = 4
        # Update explosion animation
        self.counter += 1

        if self.counter >= EXPLOSION_SPEED:
            self.counter = 0
            self.frame_index += 1
            if self.frame_index >= len(self.images):
                self.kill()
            else:
                self.image = self.images[self.frame_index]


class Goofballs(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.timer = 100
        self.vel_y = -11
        self.speed = 6
        self.image = goofball_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.on_ground = False
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.direction = direction

    def update(self):
        self.vel_y += GRAVITY
        dx = self.direction * self.speed + screen_scroll
        dy = self.vel_y

        # check for collision with level
        for tile in world.obstacle_list:
            # check collision with walls
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                self.direction *= -1
                dx = self.direction * self.speed
            # check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                self.speed = 0
                # check if below the ground, i.e. thrown up
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                # check if above the ground, i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    dy = tile[1].top - self.rect.bottom

        # update grenade position
        self.rect.x += dx + screen_scroll
        self.rect.y += dy

        # countdown timer
        self.timer -= 1
        if self.timer <= 0:
            self.kill()
            explosion = Explosion(self.rect.x, self.rect.y, 0.5)
            explosion_group.add(explosion)
            # do damage to anyone that is nearby
            if abs(self.rect.centerx - player.rect.centerx) < TILE_SIZE * 2 and \
                    abs(self.rect.centery - player.rect.centery) < TILE_SIZE * 2:
                player.health -= 50
            for enemy in enemy_group:
                if abs(self.rect.centerx - enemy.rect.centerx) < TILE_SIZE * 2 and \
                        abs(self.rect.centery - enemy.rect.centery) < TILE_SIZE * 2:
                    enemy.health -= 50


heal_img = pygame.image.load('health_box.png')
goofball_box = pygame.image.load('wooden_box.png')
mana_box = pygame.image.load('ammo_box.png')
item_boxes = {
    'Health': heal_img,
    'Mana': mana_box,
    'GOOFBALL': goofball_box
}


class World():
    def __init__(self):
        self.obstacle_list = []

    def draw(self):
        for tile in self.obstacle_list:
            tile[1][0] += screen_scroll
            screen.blit(tile[0], tile[1])

    def process_data(self, data):
        self.level_length = len(data[0])
        for y, row in enumerate(data):
            for x, tile in enumerate(row):
                if tile >= 0:
                    img = img_list[tile]  # Get the image
                    img_rect = img.get_rect()  # Create a rect for positioning
                    img_rect.x = x * TILE_SIZE
                    img_rect.y = y * TILE_SIZE
                    tile_data = (img, img_rect)

                    # Differentiate between obstacle and other tiles
                    if tile >= 0 and tile <= 6:  # Obstacles
                        self.obstacle_list.append(tile_data)
                    elif tile == 7:
                        coin = Coin(x * TILE_SIZE + TILE_SIZE // 2, y * TILE_SIZE + TILE_SIZE // 2)
                        coin_group.add(coin)
                    elif tile == 8:  # Minion spawn point
                        minion = Minion('minion', x * TILE_SIZE, (y * TILE_SIZE) + TILE_SIZE - 60, 1.3, 2, 400)
                        enemy_group.add(minion)  # Add minion to enemy group for update and drawing
                    elif tile >= 9 and tile <= 10:  # Water
                        water = Water(img, x * TILE_SIZE, y * TILE_SIZE, 50, 50)
                        water_group.add(water)
                    elif tile >= 11 and tile <= 14:  # decorations
                        decoration = Decoration(img, x * TILE_SIZE, y * TILE_SIZE, 50, 50)
                        decoration_group.add(decoration)
                    elif tile == 15:  # Player starting position
                        player = Wizard('player', x * TILE_SIZE, (y * TILE_SIZE) + TILE_SIZE - 60, 1.3, 3, 10, 5)
                    elif tile == 16:  # Enemy spawn point
                        enemy_ai = EnemyAI('enemy', x * TILE_SIZE, y * TILE_SIZE - 17, 2.5, 3, 500)
                        enemy_group.add(enemy_ai)
                    elif tile == 19:  # Health item box
                        item_box = ItemBox('Health', x * TILE_SIZE, y * TILE_SIZE, 29, 29)
                        item_box_group.add(item_box)
                    elif tile == 18:  # Goofball item box
                        item_box2 = ItemBox('GOOFBALL', x * TILE_SIZE, y * TILE_SIZE, 40, 40)
                        item_box_group.add(item_box2)
                    elif tile == 17:  # Mana item box
                        item_box3 = ItemBox('Mana', x * TILE_SIZE, y * TILE_SIZE, 40, 40)
                        item_box_group.add(item_box3)
                    elif tile == 20:
                        exit = Exit(img, x * TILE_SIZE, y * TILE_SIZE, 50)
                        exit_group.add(exit)

        return player


class Minion(Wizard):
    def __init__(self, char_type, x, y, scale, speed, patrol_range, detection_range=120):
        super().__init__(char_type, x, y, scale, speed, mana=0, goofball=0)
        self.patrol_range = patrol_range
        self.patrol_direction = 0  # Start moving left (-1) since the image initially faces left
        self.patrol_start = x
        self.patrol_end = x + patrol_range
        self.detection_range = detection_range  # Range to detect player
        self.melee_range = 40  # Range for melee attack
        self.attack_cooldown = 0

        # Start with health and max health for the minion
        self.health = 50
        self.max_health = self.health

        # Define dialogues for minion interactions
        self.dialogues = ["Minion ready to fight!", "I will defeat you!", "Attack!"]
        self.dialogue_text = ""  # To store the active dialogue
        self.dialogue_timer = 0

        # Set the initial flip to True, since the minion faces left
        self.flip = False

        # Load animations for the minion
        animation_types = ['Idle', 'Walk', 'Attack', 'Death']
        for animation in animation_types:
            temp_list = []
            num_of_frames = len(os.listdir(f'{self.char_type}/{animation}'))
            for i in range(num_of_frames):
                img = pygame.image.load(f'{self.char_type}/{animation}/{i}.png').convert_alpha()
                img = pygame.transform.scale(img, (int(40 * scale), int(58 * scale)))
                temp_list.append(img)
            self.animation_list.append(temp_list)

        # Set initial image and rect for the minion
        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.rect.bottom = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()

        # Create health bar for the minion
        self.health_bar = HealthBar(x, y - 20, width=50, height=10, border_color=(0, 0, 0), fill_color=(255, 0, 0))

    def move(self, moving_left, moving_right, player_detected=False, player=None):
        dx = 0
        dy = 0

        # Apply gravity
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y = 10  # Limit falling speed
        dy += self.vel_y

        # If player is detected, chase the player
        if player_detected and player:
            if player.rect.centerx > self.rect.centerx:
                dx = self.speed  # Move right towards the player
                self.direction = -1
                self.flip = True
            elif player.rect.centerx < self.rect.centerx:
                dx = -self.speed  # Move left towards the player
                self.direction = 1
                self.flip = False
            self.update_action(1)  # Run animation when chasing

        # If no player is detected, continue patrolling
        elif not player_detected:
            if moving_left:
                dx = -self.speed
                self.flip = True
                self.direction = -1
                self.update_action(1)  # Run animation
            elif moving_right:
                dx = self.speed
                self.flip = False
                self.direction = 1
                self.update_action(1)  # Run animation
            else:
                self.update_action(0)  # Idle animation

        # Handle collisions and movement
        for tile in world.obstacle_list:
            # Check collision with walls
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
            # Check collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.vel_y >= 0:
                    self.vel_y = 0
                    self.in_air = False
                    dy = tile[1].top - self.rect.bottom

        # Update position
        self.rect.x += dx
        self.rect.y += dy
        self.rect.x += screen_scroll

    def patrol(self):
        # Patrol logic based on patrol direction
        if self.rect.x <= self.patrol_start:
            self.patrol_direction = 1  # Move right
        elif self.rect.x >= self.patrol_end:
            self.patrol_direction = -1  # Move left

        # Call move method to handle movement logic
        self.move(moving_left=self.patrol_direction == -1, moving_right=self.patrol_direction == 1)

    def melee_attack(self, player):
        # Check horizontal and vertical distance between minion and player
        horizontal_distance = abs(self.rect.centerx - player.rect.centerx)
        vertical_distance = abs(self.rect.centery - player.rect.centery)

        # If player is within melee range, attack
        if horizontal_distance <= self.melee_range and vertical_distance <= player.height * 0.5:
            if self.attack_cooldown == 0:
                player.health -= 20  # Reduce player's health by 20
                self.attack_cooldown = 30  # Set cooldown for attack
                self.update_action(2)  # Switch to Attack animation

    def say_random_dialogue(self):
        if random.random() < 0.01 and self.dialogue_timer <= 0:
            self.dialogue_text = random.choice(self.dialogues)
            self.dialogue_timer = 3000  # Display for 3 seconds

    def update(self, player):
        # Check if minion is alive
        self.check_alive()
        if self.alive:
            # Detect player within range
            player_detected = self.detect_player(player)

            # Say random dialogue
            if player_detected:
                self.say_random_dialogue()
                self.melee_attack(player)

            # Move based on detection or patrol
            if self.attack_cooldown == 0:
                self.move(self.patrol_direction == -1, self.patrol_direction == 1, player_detected, player)
            else:
                self.attack_cooldown -= 1

            self.update_animation()

    def check_alive(self):
        # If health is 0 or below, mark as dead
        if self.health <= 0:
            self.health = 0
            self.alive = False
            player.score.increment(5 )  # Increment player score
            self.update_action(3)  # Switch to Death animation
            self.kill()

    def detect_player(self, player):
        # Check if player is within detection range
        distance_to_player = abs(self.rect.centerx - player.rect.centerx)
        if distance_to_player <= self.detection_range:
            return True
        return False

    def draw(self):
        if self.alive:
            # Draw the minion sprite and health bar
            screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)
            if self.dialogue_timer > 0:
                draw_text(self.dialogue_text, font, RED, self.rect.x, self.rect.y - 30)

            # Draw health bar above the minion
            self.health_bar.x = self.rect.x + (self.width - self.health_bar.width) // 2
            self.health_bar.y = self.rect.y - self.health_bar.height - 5
            self.health_bar.draw(self.health, self.max_health)


class Water(pygame.sprite.Sprite):
    def __init__(self, img, x, y, width=None, height=None):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += screen_scroll


class Exit(pygame.sprite.Sprite):
    def __init__(self, img, x, y, width=None, height=None):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += screen_scroll


class Decoration(pygame.sprite.Sprite):
    def __init__(self, img, x, y, width=None, height=None):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += screen_scroll


class ScreenFade():
    def __init__(self, direction, colour, speed):
        self.direction = direction
        self.colour = colour
        self.speed = speed
        self.fade_counter = 0

    def fade(self):
        fade_complete = False
        self.fade_counter += self.speed
        if self.direction == 1:  # whole screen fade
            pygame.draw.rect(screen, self.colour, (0 - self.fade_counter, 0, SCREEN_WIDTH // 2, SCREEN_HEIGHT))
            pygame.draw.rect(screen, self.colour,
                             (SCREEN_WIDTH // 2 + self.fade_counter, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.draw.rect(screen, self.colour, (0, 0 - self.fade_counter, SCREEN_WIDTH, SCREEN_HEIGHT // 2))
            pygame.draw.rect(screen, self.colour,
                             (0, SCREEN_HEIGHT // 2 + self.fade_counter, SCREEN_WIDTH, SCREEN_HEIGHT))
        if self.direction == 2:  # vertical screen fade down
            pygame.draw.rect(screen, self.colour, (0, 0, SCREEN_WIDTH, 0 + self.fade_counter))
        if self.fade_counter >= SCREEN_WIDTH:
            fade_complete = True

        return fade_complete


# create screen fades
intro_fade = ScreenFade(1, BLACK, 4)
death_fade = ScreenFade(2, PINK, 4)


class ItemBox(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y, width=None, height=None):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type
        self.image = item_boxes[self.item_type]

        # If width and height are specified, scale the image
        if width and height:
            self.image = pygame.transform.scale(self.image, (width, height))

        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        # check player pick up the box
        self.rect.x += screen_scroll
        if pygame.sprite.collide_rect(self, player):
            # check what box he picked up
            if self.item_type == 'Health':
                player.health += 25
                if player.health > player.max_health:
                    player.health = player.max_health
            elif self.item_type == 'Mana':
                player.mana += 20
            elif self.item_type == 'GOOFBALL':
                player.goofball += 5
            # delete box
            self.kill()


# Create sprite groups
coin_group = pygame.sprite.Group()  # Create a group for coins
start_button = button.Button(SCREEN_WIDTH // 2 - 130, SCREEN_HEIGHT // 2 - 150, start_img, 1)
exit_button = button.Button(SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 +50 , exit_img, 1)
restart_button = button.Button(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 100, restart_img, 2)

enemy_group = pygame.sprite.Group()
fireball_group = pygame.sprite.Group()
goofball_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
item_box_group = pygame.sprite.Group()
water_group = pygame.sprite.Group()
decoration_group = pygame.sprite.Group()
exit_group = pygame.sprite.Group()

# create empty tile list
world_data = []
for row in range(ROWS):
    r = [-1] * COLS
    world_data.append(r)
# load in level data and create world
# Load in level data and create world
with open(f'level{level}_data.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    for x, row in enumerate(reader):
        for y, tile in enumerate(row):
            world_data[x][y] = int(tile)

world = World()
player = world.process_data(world_data)
BLUE = (135,206,250)
run = True
while run:

    clock.tick(FPS)
    if start_game == False:
        screen.blit(BG,(0,0))
        draw_text('American Wizard', pygame.font.SysFont('Algerian', 100), BLUE, SCREEN_WIDTH // 2 -450, 100)
        if start_button.draw(screen):
            start_game = True
            start_intro = True
        if exit_button.draw(screen):
            run = False

    else:
        draw_bg()

        # Show player mana
        draw_text(f'Fireball: ', font, WHITE, 10, 35)
        for x in range(player.mana):
            screen.blit(fireball_img, (100 + (x * 10), 40))

        # Show goofball count
        draw_text(f'Goofball: ', font, WHITE, 10, 60)
        for x in range(player.goofball):
            screen.blit(goofball_img, (110 + (x * 10), 60))

        # Update and draw player
        player.update()
        player.draw()

        # Update and draw each enemy, passing the player to the update method
        for enemy in enemy_group:
            if isinstance(enemy, EnemyAI):  # Check if the enemy is using AI
                enemy.update(player)  # Pass the player object for detection and interaction
            else:
                enemy.update(player)  # Regular enemies
            enemy.draw()
        player.score.draw()

        # Update other sprite groups
        fireball_group.update()
        goofball_group.update()
        explosion_group.update()
        item_box_group.update()
        decoration_group.update()
        water_group.update()
        exit_group.update()
        # update backgound
        coin_group.update()  # Update coins

        world.draw()
        # Draw sprite groups
        fireball_group.draw(screen)
        goofball_group.draw(screen)
        explosion_group.draw(screen)
        item_box_group.draw(screen)
        decoration_group.draw(screen)
        water_group.draw(screen)
        coin_group.draw(screen)
        exit_group.draw(screen)

        if start_intro == True:
            if intro_fade.fade():
                start_intro = False
                intro_fade.fade_counter = 0
        # Handle player controls
        if player.alive:
            if shoot:
                player.shoot()
            if throw_grenade and not grenade_thrown and player.goofball > 0:
                goofball = Goofballs(player.rect.centerx + (0.5 * player.rect.size[0] * player.direction),
                                     player.rect.centery, player.direction)
                goofball_group.add(goofball)
                grenade_thrown = True
                player.goofball -= 1
            if player.in_air:
                player.update_action(2)
            elif moving_left or moving_right:
                player.update_action(1)
            else:
                player.update_action(0)
            screen_scroll, level_complete = player.move(moving_left, moving_right)

            bg_scroll -= screen_scroll

            if level_complete:
                start_intro = True
                level += 1
                bg_scroll = 0
                world_data = reset_level()
                if level <= MAX_LEVELS:
                    with open(f'level{level}_data.csv', newline='') as csvfile:
                        reader = csv.reader(csvfile, delimiter=',')
                        for x, row in enumerate(reader):
                            for y, tile in enumerate(row):
                                world_data[x][y] = int(tile)
                    world = World()
                    player = world.process_data(world_data)

        else:

            screen_scroll = 0

            if death_fade.fade():

                # Display the player's final score before showing the buttons

                draw_text(f'Final Score: {player.score.value}', font, BLACK, SCREEN_WIDTH // 2 - 70, SCREEN_HEIGHT // 2 - 300)

                # Create the Restart button

                if restart_button.draw(screen):

                    level = 1  # Reset to Level 1 on restart

                    death_fade.fade_counter = 0

                    start_intro = True

                    bg_scroll = 0

                    world_data = reset_level()

                    # Load level 1 and recreate the world

                    with open(f'level{level}_data.csv', newline='') as csvfile:

                        reader = csv.reader(csvfile, delimiter=',')

                        for x, row in enumerate(reader):

                            for y, tile in enumerate(row):
                                world_data[x][y] = int(tile)

                    world = World()

                    player = world.process_data(world_data)

                    player.score.value = 0  # Reset score for new game

                # Create the Save button and handle score saving

                save_button = button.Button(SCREEN_WIDTH // 2 -50, SCREEN_HEIGHT // 2 - 20, save_img, 1.5)

                if save_button.draw(screen):
                    save_score(player.score.value)  # Save the current score

                # Create the Exit button below the Save button

                exit_button = button.Button(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 70, exit_img, 1)

                if exit_button.draw(screen):
                    run = False  # Exit the game

    # Handle game events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                moving_left = True
            if event.key == pygame.K_d:
                moving_right = True
            if event.key == pygame.K_SPACE:
                shoot = True
                shot_fx.play()
            if event.key == pygame.K_w and player.alive:
                player.jump = True
                jump_fx.play()
            if event.key == pygame.K_q:
                throw_grenade = True
            if event.key == pygame.K_ESCAPE:
                run = False

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving_left = False
            if event.key == pygame.K_d:
                moving_right = False
            if event.key == pygame.K_SPACE:
                shoot = False
            if event.key == pygame.K_q:
                throw_grenade = False
                grenade_thrown = False

    pygame.display.update()

pygame.quit()
