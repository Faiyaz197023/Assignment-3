import pygame

# Initialize pygame
pygame.init()

# Get the list of available fonts
available_fonts = pygame.font.get_fonts()

# Print the list of fonts
for font in available_fonts:
    print(font)

# Quit pygame
pygame.quit()
